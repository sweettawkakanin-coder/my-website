SweetTaw Updated Website

Updated product photos:
- Ube: assets/ube.jpg
- Cheese: assets/cheese.jpg
- Chocolate card: assets/ube-cheese.jpg

Updated logo:
- assets/sweettaw-logo.jpg

Deploy to Netlify:
1. Open Netlify and choose Add new project > Deploy manually.
2. Drag the entire 'sweettaw-updated' folder (or its ZIP contents) into the deploy area.
3. Netlify will publish the site and provide a new .netlify.app link.

Accounts (Log in / Register / Log out):
- Accounts are stored in the visitor's own browser (localStorage) as a demo/prototype.
- Passwords are hashed, but this is NOT real server-side security, and accounts do not sync across devices.
- Logged-in customers get their name and mobile number pre-filled at checkout.
- For real accounts, connect a backend such as Firebase Auth or Supabase.
